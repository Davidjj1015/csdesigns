<nav id="colorlib-main-nav" role="navigation">
  <a href="#" class="js-colorlib-nav-toggle colorlib-nav-toggle active"><i></i></a>
  <div class="js-fullheight colorlib-table">
    <div class="colorlib-table-cell js-fullheight">
      <div class="row no-gutters">
        <div class="col-md-12 text-center">
          <h1><a href="index.php" class="logo"><img src="images/Carina_Snyman_Designs_LogoPW.png" alt="Carina Snyman Designs Logo" height="auto" width="auto" style="max-width: calc(100% - 40px);"/></h1>
          <ul>
            <li class="active"><a href="index.php"><span>Home</span></a></li>
            <li><a href="about.php"><span>About</span></a></li>
            <li><a href="gallery.php"><span>Gallery</span></a></li>
            <li><a href="contact.php"><span>Contact</span></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</nav>
