    <footer class="ftco-footer ftco-section img">
      <div class="overlay"></div>
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-12">
            <div class="ftco-footer-widget mb24">
              <div class="ftco-heading-2"><img src="images/Carina_Snyman_Designs_LogoPW.png" alt="Carina Snyman Designs Logo" height="auto" width="auto"</img>
                <br></br>
              <p>Specialised in Wedding and Evening Couture, Tailoring and Kiddies wear.</p>
              <ul class="ftco-footer-social p-0">
                <li class="ftco-animate"><a href="https://www.facebook.com/csnymandesigns/"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="https://www.instagram.com/csnymandesigns/"><span class="icon-instagram"></span></a></li>
                <li class="ftco-animate"><a href="https://za.pinterest.com/csnymandesigns"><span class="icon-pinterest"></span></a></li>
              </ul>
            </div>
            </div>
          </div>
              <div class="col-md-12 text-center">
                <a href="index.php" >Home <pading right 7px>  </a>
                <a href="about.php" >About</a>
                <a href="gallery.php" >Gallery</a>
                <a href="contact.php" >Contact</a>
                <a href="faqs.php" >FAQS</a>
                <br></br>
                <div class="col-md-12 text-justify-center">
                  <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved <a href="https://carinasnymandesigns.co.za" target="_blank">Carina Snyman Designs</a></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
    
    
    <?php include 'includes/js.php'; ?>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-146332260-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'UA-146332260-1');
    </script>

    <!-- Facebook Pixel Code -->
    <script>
      !function(f,b,e,v,n,t,s)
      {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
      n.callMethod.apply(n,arguments):n.queue.push(arguments)};
      if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
      n.queue=[];t=b.createElement(e);t.async=!0;
      t.src=v;s=b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t,s)}(window, document,'script',
      'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', '393708347955606');
      fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
      src="https://www.facebook.com/tr?id=393708347955606&ev=PageView&noscript=1"
    /></noscript>
    <!-- End Facebook Pixel Code -->

  </body>
</html>
